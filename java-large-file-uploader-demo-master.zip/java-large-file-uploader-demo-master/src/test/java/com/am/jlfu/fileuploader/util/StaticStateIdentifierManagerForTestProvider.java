package com.am.jlfu.fileuploader.util;


import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.am.jlfu.staticstate.StaticStateIdentifierManager;



@Component
@Primary
public class StaticStateIdentifierManagerForTestProvider extends StaticStateIdentifierManager {


}
