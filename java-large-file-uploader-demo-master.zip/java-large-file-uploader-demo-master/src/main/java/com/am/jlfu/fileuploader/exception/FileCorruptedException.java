package com.am.jlfu.fileuploader.exception;


public class FileCorruptedException extends Exception{

	public FileCorruptedException(String string) {
		super(string);
	}

}
