package com.am.jlfu.fileuploader.exception;


public class BadRequestException extends Exception {

	public BadRequestException(String message) {
		super(message);
	}


}
