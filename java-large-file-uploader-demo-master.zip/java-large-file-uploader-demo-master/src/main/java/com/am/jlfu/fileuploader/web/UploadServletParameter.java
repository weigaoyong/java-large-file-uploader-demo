package com.am.jlfu.fileuploader.web;


/**
 * One of the possible parameter that the servlet handles.
 * 
 * @author antoinem
 * 
 */
public enum UploadServletParameter {

	action,
	fileId,
	crc,
	rate,
	newFiles,
	clientId;


}
